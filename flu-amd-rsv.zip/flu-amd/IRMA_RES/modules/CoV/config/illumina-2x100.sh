# HEADER
PARAM_FILE_NAME="Illumina 2x100 configuration"
PARAM_FILE_AUTHOR="B. Rambo-Martin"
PARAM_FILE_VERSION="1.0"
PARAM_FILE_DATE="2021-03-23"

MIN_LEN=50      # minimum read length

